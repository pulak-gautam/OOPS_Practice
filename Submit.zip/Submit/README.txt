Steps to run the program:
1. run the "make" command on terminal in the same directory
2. run ./main to get the terminal interface of the implementation
